#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
class node{
	public:
	int data1;
	int data2;
	node * next;
};
void Push(int x,int y,node ** head){
	node* new_node=new node;
	new_node->data1=x;
	new_node->data2=y;
	new_node->next=(*head);
	(*head)=new_node;
}
void Multiply(int z,node *head1,node *head2){
	int s=0;
	int arr[z];
	 for(int i=0; i<=z; i++)
{   s=0;
	
	 	node* temp1=head1;
	    
	 
	 	    
	 	while(temp1!=NULL)
	 	{
	 		node* temp2=head2;
	 		
	 	while(temp2!=NULL)
	 		{
	 		if(temp1->data2+temp2->data2==i)
             s+=(temp1->data1)*(temp2->data1);
             temp2=temp2->next;
                                   }
        temp1=temp1->next;
        
        
	 	        } 
	 	        if(s!=0) { 
	 	        arr[i]=s;        

	      }
	 
      }
      cout<<"coefficient power"<<endl;
  for(int i=0;i<=z;i++){
  	cout<< arr[z-i] <<"          ";
cout<<z-i<<endl; }  
}
void addition(int z,int m,node * head1,node * head2){
	
	node* temp1=head1;
	node* temp2=head2;


	 for(int i=0; i<=z; i++)
        { 
          
	int s=0;
	 	
	    if(i>m)
	    s=temp1->data1;    
	    
        else
	 	s=temp1->data1+temp2->data1;

        
        
        cout<< s <<" ";
        cout<< i<<endl;
       
        temp1=temp1->next;
	    temp2=temp2->next;
      }
     
}





int main(){
	int x,y,z;
	node * head1=NULL;
	node * head2=NULL;
	cout<<"enter number of terms in 1st expression"<<endl;
	int n1,n2;
	cin>>n1;
    cout<<"coefficient power"<<endl;
	for(int i=0; i<n1; i++){
	int a,b;
	cin>>a;
	cin>>b;
  if(i==0)
	x=b;
     Push(a,b,&head1);
    }
	cout<<"enter number of terms in 2nd expression"<<endl;
	cin>>n2;
	cout<<"coefficient power"<<endl;
	for(int i=0; i<n2; i++){
	int c,d;
	cin>>c;
	cin>>d;
    if(i==0)
	y=d;
     Push(c,d,&head2);
	}
z=x+y;
int r;
	cout<< "enter 1 to add and 2 to Multiply expressions"<<endl;
	cin>>r;

	if(r==2)
	Multiply(z,head1,head2);
	if(r==1){
	
if(x>y)
addition(x,y,head1,head2);

else
addition(y,x,head2,head1);
}
//
int k;
	cout<< "enter 1 to add and 2 to Multiply expressions"<<endl;
	cin>>k;

	if(k==2)
	Multiply(z,head1,head2);
	if(k==1){
	
if(x>y)
addition(x,y,head1,head2);

else
addition(y,x,head2,head1);
}
//

	return 0;	
}
