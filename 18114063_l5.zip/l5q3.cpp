// C / C++ program for Prim's MST for adjacency list representation of graph 
#include<bits/stdc++.h> 
#include <limits.h> 
#include <stdio.h> 
#include <stdlib.h> 
using std::cerr;
using std::endl;
#include <fstream>
using std::ofstream;
#include <cstdlib>

// A structure to represent a node in adjacency list 
struct AdjList_Node { 
	int dest; 
	int weight; 
	struct AdjList_Node* next; 
}; 

// A structure to represent an adjacency list 
struct AdjList { 
	struct AdjList_Node* head; // pointer to head node of list 
}; 

// A structure to represent a graph. A graph is an array of adjacency lists. 
// Size of array will be V (number of vertices in graph) 
struct Graph { 
	int V; 
	struct AdjList* array; 
}; 

// A utility function to create a new adjacency list node 
struct AdjList_Node* newAdjList_Node(int dest, int weight) 
{ 
	struct AdjList_Node* newNode = (struct AdjList_Node*)malloc(sizeof(struct AdjList_Node)); 
	newNode->dest = dest; 
	newNode->weight = weight; 
	newNode->next = NULL; 
	return newNode; 
} 

// A utility function that creates a graph of V vertices 
struct Graph* createGraph(int V) 
{ 
	struct Graph* graph = (struct Graph*)malloc(sizeof(struct Graph)); 
	graph->V = V; 

	// Create an array of adjacency lists. Size of array will be V 
	graph->array = (struct AdjList*)malloc(V * sizeof(struct AdjList)); 

	// Initialize each adjacency list as empty by making head as NULL 
	for (int i = 0; i < V; ++i) 
		graph->array[i].head = NULL; 

	return graph; 
} 

// Adds an edge to an undirected graph 
void add_Edge(struct Graph* graph, int src, int dest, int weight) 
{ 
	// Add an edge from src to dest. A new node is added to the adjacency 
	// list of src. The node is added at the begining 
	struct AdjList_Node* newNode = newAdjList_Node(dest, weight); 
	newNode->next = graph->array[src].head; 
	graph->array[src].head = newNode; 

	// Since graph is undirected, add an edge from dest to src also 
	newNode = newAdjList_Node(src, weight); 
	newNode->next = graph->array[dest].head; 
	graph->array[dest].head = newNode; 
} 

// Structure to represent a min heap node 
struct MinHeapNode { 
	int v; 
	int key; 
}; 

// Structure to represent a min heap 
struct MinHeap { 
	int size; // Number of heap nodes present currently 
	int capacity; // Capacity of min heap 
	int* pos; // This is needed for decreaseKey() 
	struct MinHeapNode** array; 
}; 

// A utility function to create a new Min Heap Node 
struct MinHeapNode* newMinHeapNode(int v, int key) 
{ 
	struct MinHeapNode* minHeapNode = (struct MinHeapNode*)malloc(sizeof(struct MinHeapNode)); 
	minHeapNode->v = v; 
	minHeapNode->key = key; 
	return minHeapNode; 
} 

// A utilit function to create a Min Heap 
struct MinHeap* createMinHeap(int capacity) 
{ 
	struct MinHeap* minHeap = (struct MinHeap*)malloc(sizeof(struct MinHeap)); 
	minHeap->pos = (int*)malloc(capacity * sizeof(int)); 
	minHeap->size = 0; 
	minHeap->capacity = capacity; 
	minHeap->array = (struct MinHeapNode*)malloc(capacity * sizeof(struct MinHeapNode)); 
	return minHeap; 
} 

// A utility function to swap two nodes of min heap. Needed for min heapify 
void swap_MinHeapNode(struct MinHeapNode** a, struct MinHeapNode** b) 
{ 
	struct MinHeapNode* t = *a; 
	*a = *b; 
	*b = t; 
} 

// A standard function to heapify at given idx 
// This function also updates position of nodes when they are swapped. 
// Position is needed for decreaseKey() 
void minHeapify(struct MinHeap* minHeap, int idx) 
{ 
	int smallest, left, right; 
	smallest = idx; 
	left = 2 * idx + 1; 
	right = 2 * idx + 2; 

	if (left < minHeap->size && minHeap->array[left]->key < minHeap->array[smallest]->key) 
		smallest = left; 

	if (right < minHeap->size && minHeap->array[right]->key < minHeap->array[smallest]->key) 
		smallest = right; 

	if (smallest != idx) { 
		// The nodes to be swapped in min heap 
		MinHeapNode* smallestNode = minHeap->array[smallest]; 
		MinHeapNode* idxNode = minHeap->array[idx]; 

		// Swap positions 
		minHeap->pos[smallestNode->v] = idx; 
		minHeap->pos[idxNode->v] = smallest; 

		// Swap nodes 
		swap_MinHeapNode(&minHeap->array[smallest], &minHeap->array[idx]); 

		minHeapify(minHeap, smallest); 
	} 
} 

// A utility function to check if the given minHeap is ampty or not 
int isEmpty(struct MinHeap* minHeap) 
{ 
	return minHeap->size == 0; 
} 

// Standard function to extract minimum node from heap 
struct MinHeapNode* extractMin(struct MinHeap* minHeap) 
{ 
	if (isEmpty(minHeap)) 
		return NULL; 

	// Store the root node 
	struct MinHeapNode* root = minHeap->array[0]; 

	// Replace root node with last node 
	struct MinHeapNode* lastNode = minHeap->array[minHeap->size - 1]; 
	minHeap->array[0] = lastNode; 

	// Update position of last node 
	minHeap->pos[root->v] = minHeap->size - 1; 
	minHeap->pos[lastNode->v] = 0; 

	// Reduce heap size and heapify root 
	--minHeap->size; 
	minHeapify(minHeap, 0); 

	return root; 
} 


void decreaseKey(struct MinHeap* minHeap, int v, int key) 
{ 
	// Get the index of v in heap array 
	int i = minHeap->pos[v]; 

	// Get the node and update its key value 
	minHeap->array[i]->key = key; 

	// Travel up while the complete tree is not hepified. 
	// This is a O(Logn) loop 
	while (i && minHeap->array[i]->key < minHeap->array[(i - 1) / 2]->key) { 
		// Swap this node with its parent 
		minHeap->pos[minHeap->array[i]->v] = (i - 1) / 2; 
		minHeap->pos[minHeap->array[(i - 1) / 2]->v] = i; 
		swap_MinHeapNode(&minHeap->array[i], &minHeap->array[(i - 1) / 2]); 

		// move to parent index 
		i = (i - 1) / 2; 
	} 
} 

// A utility function to check if a given vertex 
// 'v' is in min heap or not 
bool isIn_MinHeap(struct MinHeap* minHeap, int v) 
{ 
	if (minHeap->pos[v] < minHeap->size) 
		return true; 
	return false; 
} 

// A utility function used to print the constructed MST 
void printArr(int a[],int arr[], int n) 
{   ofstream outdata;
	outdata.open("/home/sai/Desktop/prims/graph2.dot"); // opens the file
   if( !outdata ) { // file couldn't be opened
      cerr << "Error: file could not be opened" << endl;
      exit(1);
   }
   outdata<<"graph{\n";
	for (int i = 1; i < n; ++i) {
		printf("%c %c %d\n", arr[i]+65, i+65,a[i]); 
        outdata << (char)(arr[i]+65)<<"--"<<(char)(i+65)<<"[label=\""<<a[i]<<"\"]"<< endl;
	}
	outdata<<"}";
	outdata.close();
} 

// The main function that constructs Minimum Spanning Tree (MST) 
// using Prim's algorithm 
void PrimMST(struct Graph* graph) 
{ 
	int V = graph->V; // Get the number of vertices in graph 
	int parent[V],a[V]; // Array to store constructed MST 
	int key[V]; // Key values used to pick minimum weight edge in cut 

	// minHeap represents set E 
	struct MinHeap* minHeap = createMinHeap(V); 

	// Initialize min heap with all vertices. Key value of 
	// all vertices (except 0th vertex) is initially infinite 
	for (int v = 1; v < V; ++v) { 
		parent[v] = -1; a[v]=-1;
		key[v] = INT_MAX; 
		minHeap->array[v] = newMinHeapNode(v, key[v]); 
		minHeap->pos[v] = v; 
	} 

	// Make key value of 0th vertex as 0 so that it 
	// is extracted first 
	key[0] = 0; 
	minHeap->array[0] = newMinHeapNode(0, key[0]); 
	minHeap->pos[0] = 0; 

	// Initially size of min heap is equal to V 
	minHeap->size = V; 

	 
	while (!isEmpty(minHeap)) { 
		// Extract the vertex with minimum key value 
		struct MinHeapNode* minHeapNode = extractMin(minHeap); 
		int u = minHeapNode->v; // Store the extracted vertex number 

		
		struct AdjList_Node* pCrawl = graph->array[u].head; 
		while (pCrawl != NULL) { 
			int v = pCrawl->dest; 

			
			if (isIn_MinHeap(minHeap, v) && pCrawl->weight < key[v]) { 
				key[v] = pCrawl->weight; 
				parent[v] = u; a[v]=pCrawl->weight;
				decreaseKey(minHeap, v, key[v]); 
			} 
			pCrawl = pCrawl->next; 
		} 
	} 

	// print edges of MST 
	printArr(a,parent, V); 
} 

// Driver program to test above functions 
int main() 
{ 
	// Let us create the graph given in above fugure 
	int V=9,s=0,count=0,i,high=0; 
	FILE *fp=fopen("p2_input.csv","r");
    char ch;
    int c1[100],c2[100];
    int a[100],store[100];
    while(EOF!=fscanf(fp,"%c",&ch)){ s--; //cout<<ch;
        if(ch=='\n') s=1;
      if(ch==',') count++;
      if(ch!=','&&ch!='\n'&&(int)ch>45){ 
      if(count%2==0){
    if(s>=0||count==0) {c1[count/2]=(int)ch-65; if(c1[count/2]>high) high=c1[count/2]; }
        else{ if((int)ch!=13) a[count/2-1]=(int)ch; if(a[count/2-1]>13) a[count/2-1]-=48;  }
      }
      else{
         c2[(count-1)/2]=(int)ch-65;
         if(c2[(count-1)/2]>high) high=c2[(count-1)/2];
      }
  }
    }
    V=high+1;
    struct Graph* graph = createGraph(V); 
	for(i=0;i<count/2;i++){
        add_Edge(graph,c1[i],c2[i],a[i]);
    }


	PrimMST(graph); 

	return 0; 
} 



